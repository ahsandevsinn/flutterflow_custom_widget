package com.example.flutterflow_custom_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
